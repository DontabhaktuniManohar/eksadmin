import aws_cdk as cdk
from aws_cdk import App
from cdk_demo.cdk_demo_stack import CdkDemoStack


app = App()


stack = CdkDemoStack(app, "MyFirstEcsCluster")
app.synth()
