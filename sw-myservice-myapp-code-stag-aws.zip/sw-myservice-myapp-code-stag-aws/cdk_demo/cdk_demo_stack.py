from aws_cdk import (
    aws_sns as sns,
    aws_cloudwatch as cloudwatch,
    App, Stack,Duration,
    aws_sqs as sqs,
    aws_iam as iam,
    aws_lambda as _lambda,
    CfnParameter as Cfn,
    aws_sns_subscriptions as subs,
    aws_kms as kms,
    aws_logs as logs,
    aws_events as events,
    aws_events_targets as targets,
    aws_ssm as ssm,
    aws_cloudwatch_actions as cloudwatch_actions
)
from constructs import Construct


class CdkDemoStack(Stack):

    def __init__(self, scope: Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)
        ClusterName = Cfn(self, "ClusterName",type="String",description="Name of the cluster")
        ClusterServiceName = Cfn(self, "ClusterServiceName",type="String",description="Name of the service")
        pDeadLetterQueueName = Cfn(self, "pDeadLetterQueueName", type="String")
        pDefaultEnv = Cfn(self, "pDefaultEnv", type="String")
        pCentralMonitorSNSTopicName = Cfn(self, "pCentralMonitorSNSTopicName", type="String")
        pFirstCentralMonitoringToolAccountRegion = Cfn(self, "pFirstCentralMonitoringToolAccountRegion", type="String")
        pSecondCentralMonitoringToolAccountRegion = Cfn(self, "pSecondCentralMonitoringToolAccountRegion", type="String")
        pCentralMonitoringToolAccountId = Cfn(self, "pCentralMonitoringToolAccountId", type="String")
        pKmsMasterKeyId = Cfn(self, "pKmsMasterKeyId", type="String"),
        pKmsMRKIdForMonitoring = Cfn(self, "pKmsMRKIdForMonitoring", type="String")
        pKmsMaster_StrKeyId = str(pKmsMasterKeyId)
        kms_alias_arn = f"arn:aws:kms:{pFirstCentralMonitoringToolAccountRegion.value_as_string}:{pCentralMonitoringToolAccountId.value_as_string}:alias/{pKmsMaster_StrKeyId}"
        kms_key = kms.Key.from_key_arn(self, "ExistingKMSAlias", kms_alias_arn)
        rDeadLetterQueue = sqs.Queue(
            self, "DeadLetterQueue",
            queue_name=pDeadLetterQueueName.value_as_string,
            encryption_master_key=kms_key,
        )
        # Define the IAM role for the Lambda function
        lambda_role = iam.Role(self, "LambdaExecutionRole",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
        )
        # Attach an IAM policy statement granting permissions
        lambda_role.add_to_policy(iam.PolicyStatement(
            actions=["sqs:SendMessage", "sqs:ReceiveMessage"],  
            resources=[rDeadLetterQueue.queue_arn], 
            effect=iam.Effect.ALLOW
        ))
        lambda_role.add_to_policy(iam.PolicyStatement(
            actions=["kms:GenerateDataKey", "kms:Decrypt"],  
            resources=[f"arn:aws:kms:{pSecondCentralMonitoringToolAccountRegion.value_as_string}:{pCentralMonitoringToolAccountId.value_as_string}:key/{pKmsMRKIdForMonitoring.value_as_string}",
                       f"arn:aws:kms:{pSecondCentralMonitoringToolAccountRegion.value_as_string}:{pCentralMonitoringToolAccountId.value_as_string}:key/{pKmsMRKIdForMonitoring.value_as_string}"
                       ], 
            effect=iam.Effect.ALLOW
        ))
        lambda_role.add_to_policy(iam.PolicyStatement(
            actions=["sns:GetTopicAttributes", "sns:Publish"],  
            resources=[f"arn:aws:sns:{pFirstCentralMonitoringToolAccountRegion.value_as_string}:{pCentralMonitoringToolAccountId.value_as_string}:{pCentralMonitorSNSTopicName.value_as_string}-{pFirstCentralMonitoringToolAccountRegion.value_as_string}-main-aws"
                       ], 
            effect=iam.Effect.ALLOW
        ))
        lambda_role.add_to_policy(iam.PolicyStatement(
            actions=["sns:GetTopicAttributes", "sns:Publish"],  
            resources=[f"arn:aws:sns:{pSecondCentralMonitoringToolAccountRegion.value_as_string}:{pCentralMonitoringToolAccountId.value_as_string}:{pCentralMonitorSNSTopicName.value_as_string}-{pSecondCentralMonitoringToolAccountRegion.value_as_string}-main-aws"
                       ], 
            effect=iam.Effect.ALLOW
        ))
        lambda_role.add_managed_policy(iam.ManagedPolicy.from_aws_managed_policy_name("service-role/AWSLambdaBasicExecutionRole"))
        lambda_role.add_managed_policy(iam.ManagedPolicy.from_aws_managed_policy_name("AmazonSQSFullAccess"))
        lambda_role.add_managed_policy(iam.ManagedPolicy.from_aws_managed_policy_name("IAMReadOnlyAccess"))
        lambda_fn = _lambda.Function(
            self, "SnsForwarderLambda",
            runtime=_lambda.Runtime.PYTHON_3_8,
            handler="lambda_function.lambda_handler", 
            code=_lambda.Code.from_asset("lambda_function.zip"),
            role=lambda_role,
            dead_letter_queue=rDeadLetterQueue,
            environment={
                "eFirstTargetSNSTopicArn": f"arn:aws:sns:{pFirstCentralMonitoringToolAccountRegion.value_as_string}:{pCentralMonitoringToolAccountId.value_as_string}:{pCentralMonitorSNSTopicName.value_as_string}-{pFirstCentralMonitoringToolAccountRegion.value_as_string}-main-aws",
                "eSecondTargetSNSTopicArn":f"arn:aws:sns:{pSecondCentralMonitoringToolAccountRegion.value_as_string}:{pCentralMonitoringToolAccountId.value_as_string}:{pCentralMonitorSNSTopicName.value_as_string}-{pSecondCentralMonitoringToolAccountRegion.value_as_string}-main-aws",
                "eFirstTargetRegion":pFirstCentralMonitoringToolAccountRegion.value_as_string,
                "eSecondTargetRegion":pSecondCentralMonitoringToolAccountRegion.value_as_string,
                "eEnvironment": pDefaultEnv.value_as_string
            }
        )
        
        topic = sns.Topic(self, "MyTopic",
                          master_key=kms_key
                          )
        print(topic.topic_arn)
        topic.add_subscription(subs.LambdaSubscription(lambda_fn))
        topic.grant_publish(lambda_fn)
        lambda_fn.add_permission("snsInvokePermission",
            principal=iam.ServicePrincipal("sns.amazonaws.com"),
            action="lambda:InvokeFunction",
            source_arn=topic.topic_arn
        )

        log_group = logs.LogGroup(self, "MyLambdaLogGroup",
            log_group_name="/aws/lambda/" + lambda_fn.function_name,
            retention=logs.RetentionDays.ONE_MONTH
        )

        # Grant the Lambda function permission to assume the IAM role
        lambda_fn.add_to_role_policy(iam.PolicyStatement(
            actions=["sts:AssumeRole"],
            resources=[lambda_role.role_arn]
        ))
        health_event_rule = events.Rule(
            self, "HealthEventRule",
            rule_name=f"sw-health-event-rule-{pFirstCentralMonitoringToolAccountRegion.value_as_string}-main-aws",
            description="Health Rule",
            event_pattern= {
                "source": ["aws.health"],
                "detail": {
                    "eventTypeCategory": [
                        "issue", "accountNotification", "scheduledChange"
                    ],
                    "service": [
                        "AUTOSCALING", "VPC", "EC2", "RDS", "IAM", "CLOUDTRAIL",
                        "S3", "ACM", "CODEDEPLOY", "KMS", "FIREHOSE", "CLOUDWATCH",
                        "ECR", "VPC", "INSPECTOR", "ROUTE53", "EVENTS",
                        "CLOUDFORMATION", "SECURITY", "ELASTICLOADBALANCING",
                        "CODEPIPELINE", "KINESIS", "APIGATEWAY", "SQS", "CODECOMMIT",
                        "DYNAMODB", "SNS", "LAMBDA", "EBS", "DIRECTCONNECT",
                        "CODEBUILD", "EKS", "GUARDDUTY", "ORGANIZATIONS",
                        "SECRETSMANAGER", "SSM", "XRAY", "SSO", "BACKUP",
                        "NATEGATEWAY", "RAM", "ROUTE53RESOLVER", "SECURITYHUB",
                        "TRANSIT_GATEWAY", "KINESISSTREAMS"
                    ]
                }
            },
            targets=[targets.LambdaFunction(lambda_fn)]
        )
        lambda_fn.add_permission(
            "HealthEventRuleInvoke",
            action="lambda:InvokeFunction",
            principal=iam.ServicePrincipal("events.amazonaws.com"),
            source_arn=health_event_rule.rule_arn
        )
        ssm.StringParameter(
            self, "MonitoringSNSTopicARN",
            parameter_name=f"/org/primary/monitoring-sns/{pFirstCentralMonitoringToolAccountRegion.value_as_string}",
            string_value=topic.topic_arn,
            simple_name=True ,
            description="Monitoring SNS Topic"
        )

        cpu_utilization_metric = cloudwatch.Metric(
                    namespace='AWS/ECS',
                    metric_name='CPUUtilization',
                    dimensions_map={
                        "ClusterName": ClusterName.value_as_string,
                        "ServiceName": ClusterServiceName.value_as_string
                    },
                    period=Duration.minutes(5),
                    statistic='Average'
                )
        memory_utilization_metric = cloudwatch.Metric(
                namespace='AWS/ECS',
                metric_name='MemoryUtilization',
                dimensions_map={
                    "ClusterName": ClusterName.value_as_string,
                    "ServiceName": ClusterServiceName.value_as_string
                },
                period=Duration.minutes(5),
                statistic='Average'
            )

        cpu_utilization_alarm = cloudwatch.Alarm(
            self, "CpuUtilizationAlarm",
            metric=cpu_utilization_metric,
            threshold=1,
            evaluation_periods=2
        )
        memory_utilization_alarm = cloudwatch.Alarm(
                self, "MemoryUtilizationAlarm",
                metric=memory_utilization_metric,
                threshold=80,
                evaluation_periods=2
            )
        cpu_utilization_alarm.add_alarm_action(
            cloudwatch_actions.SnsAction(topic)
        )
        memory_utilization_alarm.add_alarm_action(
            cloudwatch_actions.SnsAction(topic)
        )

