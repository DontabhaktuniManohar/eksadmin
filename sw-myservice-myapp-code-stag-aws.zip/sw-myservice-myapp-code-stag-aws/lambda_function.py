import gzip
import json
import base64
import boto3
import sys
import os

def lambda_handler(event, context):
    
    firstSNSTargetArn = os.environ['eFirstTargetSNSTopicArn']
    firstRegion = os.environ['eFirstTargetRegion']
    defaultenv = os.environ['eEnvironment']

    client = boto3.client("iam")
    response = client.list_account_aliases()
    aliases = response['AccountAliases']
    if len(aliases) > 0:
        defaultenv = aliases[0].split("-")[-3]

    message = []
    if 'Records' in event.keys():
        message = event['Records']
        print("From SNS: ", message)
    elif 'awslogs'in event.keys():
        cw_data = event['awslogs']['data']
        compressed_payload = base64.b64decode(cw_data)
        uncompressed_payload = gzip.decompress(compressed_payload)
        payload = json.loads(uncompressed_payload)

        for log_event in payload['logEvents']:
            record = json.loads(log_event['message'])
            record['type'] = 'APPEvent'
            message.append(record)
            print(f'data: {record}')
    else:
        print("Health Message: ", event)

    if len(message) > 0:     
        try:
            
            client = boto3.client('sns', region_name=firstRegion)
            for record in message:
                if 'Sns' in record and 'Type' in record['Sns'] and record['Sns']['Type'] == 'Notification':
                    msg = json.loads(record['Sns']['Message'])
                    msg['cloud_environment'] = defaultenv
                    record['Sns']['Message'] = json.dumps(msg)
                else:
                    record['cloud_environment'] = defaultenv
                print("Sending Record : ", record)
                response = client.publish(
                    TargetArn=firstSNSTargetArn,
                    Message=json.dumps(record)
                )
        except:
            print("Unexpected error while sending SNS message to first central region topic: ", sys.exc_info()[0])

            secondSNSTargetArn = os.environ['eSecondTargetSNSTopicArn']
            secondRegion = os.environ['eSecondTargetRegion']
        
            try:
                client = boto3.client('sns', region_name=secondRegion)
                for record in message:
                    if 'Sns' in record and 'Type' in record['Sns'] and record['Sns']['Type'] == 'Notification':
                        msg = json.loads(record['Sns']['Message'])
                        msg['cloud_environment'] = defaultenv
                        record['Sns']['Message'] = json.dumps(msg)
                    else:
                        record['cloud_environment'] = defaultenv
                    print("Sending Record : ", record)
                    response = client.publish(
                        TargetArn=secondSNSTargetArn,
                        Message=json.dumps(record)
                    )
            except:
                print("Unexpected error while sending SNS message to second central region topic: ", sys.exc_info()[0])
                raise ServerUnavailableException("SNS service is not available")
    
    return "ok"
