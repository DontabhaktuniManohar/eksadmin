from aws_cdk import (
     App,
     DefaultStackSynthesizer,
     Environment
     )
import aws_cdk as cdk
import configparser
from ecs_fargate_alaram.ecs_fargate_alaram import ECSClusterFargateServiceAlaram


if __name__=='__main__':
    # Reading Application infra resource varibales using git branch name  
    config_parser = configparser.ConfigParser()
    config_parser.read(filenames="resource.config")
    config = config_parser['develop']
    
    app = App()
    stack = ECSClusterFargateServiceAlaram(app, 
                         "EcsClusterFargetServiceAlaram",
                         resource_config=config
                        )
    app.synth()
