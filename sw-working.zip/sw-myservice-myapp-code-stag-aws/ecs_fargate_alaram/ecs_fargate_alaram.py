from aws_cdk import (
    App,Stack,
    aws_ecs as ecs,
    aws_ec2 as ec2,
    aws_cloudwatch as cloudwatch,
    aws_sns as sns,
    aws_ssm as ssm,
    aws_logs as logs,
    aws_kms as kms,
    aws_cloudwatch_actions as cloudwatch_actions,
    RemovalPolicy,
)
from constructs import Construct

class ECSClusterFargateServiceAlaram(Stack):

    def __init__(self, scope: Construct, id: str,resource_config: dict, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)
        config = resource_config
        

        # Define the VPC
        vpc = ec2.Vpc(self, config['vpc_id'], max_azs=int(config['vpc_max_azs']))

        # Define an ECS Cluster
        cluster = ecs.Cluster(self, config['cluster_id'], vpc=vpc)

        # Create an ECS Task Definition with Fargate
        task_definition = ecs.FargateTaskDefinition(self, config['task_definition_id'])

        # Add a container to the task definition
        container = task_definition.add_container(
            config['container_id'],
            image=ecs.ContainerImage.from_registry(config['container_image']),
            logging=ecs.LogDrivers.aws_logs(stream_prefix=config['log_stream_prefix']),
        )

        # Define the ECS Service to run the Task Definition on Fargate
        service = ecs.FargateService(self, config['service_id'],
                                     cluster=cluster,
                                     task_definition=task_definition,
                                     desired_count=int(config['desired_count']))
        encryption_key = kms.Key(
            self, config['encryptionkey_name'],
            enable_key_rotation=True  # Enable key rotation for better security
        )
        snstopic = sns.Topic(
            self, config['snstopic_name'],
            master_key=encryption_key
        )
        # ssm.StringParameter(
        #     self, config['ssmsnstopicname'],
        #     parameter_name=config['sns_topic_arn_parameter_name'],
        #     string_value=snstopic.topic_arn
        # )
        # # Retrieve the SNS topic ARN from SSM Parameter Store
        # sns_topic_arn_parameter = ssm.StringParameter.from_string_parameter_attributes(
        #     self, config['sns_topic_arn_parameter_id'],
        #     parameter_name=config['sns_topic_arn_parameter_name'],
        # )
        # Use the SNS topic ARN from the SSM parameter
        sns_topic = sns.Topic.from_topic_arn(
            self, config['sns_topic_id'],
            topic_arn=snstopic.topic_arn
        )

        # Create a CloudWatch alarm for CPU Utilization
        cpu_utilization_alarm = cloudwatch.Alarm(self, config['cpu_alarm_id'],
                                                 metric=service.metric_cpu_utilization(),
                                                 threshold=int(config['cpu_utilization_threshold']),
                                                 evaluation_periods=int(config['evaluation_periods']),
                                                 datapoints_to_alarm=int(config['datapoints_to_alarm']),
                                                 alarm_description="Alarm if CPU exceeds the threshold",
                                                 treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING)

        # Subscribe the SNS topic to the CPU alarm
        cpu_utilization_alarm.add_alarm_action(cloudwatch_actions.SnsAction(sns_topic))

        # Create a CloudWatch alarm for Memory Utilization
        memory_utilization_alarm = cloudwatch.Alarm(self, config['memory_alarm_id'],
                                                    metric=service.metric_memory_utilization(),
                                                    threshold=int(config['memory_utilization_threshold']),
                                                    evaluation_periods=int(config['evaluation_periods']),
                                                    datapoints_to_alarm=int(config['datapoints_to_alarm']),
                                                    alarm_description="Alarm if Memory exceeds the threshold",
                                                    treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING)

        # Subscribe the SNS topic to the Memory alarm
        memory_utilization_alarm.add_alarm_action(cloudwatch_actions.SnsAction(sns_topic))

        # Create log group for the container
        log_group = logs.LogGroup(self, config['log_group_id'],
                                  log_group_name=f"/ecs/{service.service_name}",
                                  removal_policy=RemovalPolicy.DESTROY)

